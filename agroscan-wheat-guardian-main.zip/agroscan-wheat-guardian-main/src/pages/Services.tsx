
import React, { useState } from 'react';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Download, Upload } from 'lucide-react';
import { toast } from 'sonner';

const Services = () => {
  const [file, setFile] = useState<File | null>(null);
  const [imageId, setImageId] = useState('');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<{
    class: string;
    infectionPercent: number;
    finalResult: string;
    originalImage: string;
    maskImage: string;
    highlightedImage: string;
  } | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setPreviewUrl(URL.createObjectURL(selectedFile));
    }
  };

  const handleImageIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImageId(e.target.value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!file) {
      toast.error("Please select an image file");
      return;
    }
    
    if (!imageId.trim()) {
      toast.error("Please enter an Image ID");
      return;
    }
    
    // Simulate analysis with loading state
    setIsAnalyzing(true);
    
    // This would normally connect to your Python backend
    // For this demo, we'll simulate the AI analysis with a timeout
    setTimeout(() => {
      // Mock results
      setResults({
        class: "MRMS",
        infectionPercent: 22,
        finalResult: "22MRMS",
        originalImage: previewUrl!,
        maskImage: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=224&ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTcxNzI2NTAzMA&ixlib=rb-4.0.3&q=80&w=224",
        highlightedImage: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=224&ixid=MnwxfDB8MXxyYW5kb218MHx8fHx8fHx8MTcxNzI2NTA4OA&ixlib=rb-4.0.3&q=80&w=224",
      });
      
      setIsAnalyzing(false);
      toast.success("Analysis completed successfully");
    }, 2000);
  };

  const handleDownloadReport = () => {
    if (!results) return;
    
    // This would normally generate a PDF report
    // For this demo, we'll just show a success toast
    toast.success("Report downloaded successfully");
  };

  return (
    <Layout>
      <div className="page-container">
        <h1 className="section-heading text-center">Wheat Rust Analyzer</h1>
        
        <div className="max-w-3xl mx-auto">
          {!results ? (
            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Upload Wheat Image for Analysis</CardTitle>
                <CardDescription>
                  Upload a clear image of wheat leaves to analyze for rust disease
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="imageId">Image ID</Label>
                    <Input
                      id="imageId"
                      placeholder="Enter a unique ID for this image"
                      value={imageId}
                      onChange={handleImageIdChange}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="image">Upload Image</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-agro-primary transition-colors" onClick={() => document.getElementById('image')?.click()}>
                      <input
                        id="image"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                      {previewUrl ? (
                        <div className="space-y-4">
                          <img src={previewUrl} alt="Preview" className="max-h-48 mx-auto rounded-lg" />
                          <p className="text-sm text-gray-500">Click to change image</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <Upload className="h-12 w-12 text-gray-400 mx-auto" />
                          <p className="text-sm text-gray-500">Click to upload or drag and drop</p>
                          <p className="text-xs text-gray-400">PNG, JPG, GIF up to 10MB</p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-agro-primary hover:bg-agro-dark"
                    disabled={isAnalyzing}
                  >
                    {isAnalyzing ? "Analyzing..." : "Analyze Image"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          ) : (
            <div className="mt-8 space-y-8">
              {/* Results Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Analysis Results</CardTitle>
                  <CardDescription>Image ID: {imageId}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className="border rounded-lg p-4 text-center">
                      <h3 className="text-lg font-medium text-gray-700">Predicted Class</h3>
                      <p className="text-2xl font-bold text-agro-primary mt-2">{results.class}</p>
                    </div>
                    <div className="border rounded-lg p-4 text-center">
                      <h3 className="text-lg font-medium text-gray-700">Infected Area</h3>
                      <p className="text-2xl font-bold text-agro-primary mt-2">{results.infectionPercent}%</p>
                    </div>
                    <div className="border rounded-lg p-4 text-center">
                      <h3 className="text-lg font-medium text-gray-700">Final Result</h3>
                      <p className="text-2xl font-bold text-agro-primary mt-2">{results.finalResult}</p>
                    </div>
                  </div>
                  
                  <h3 className="text-lg font-medium text-gray-700 mb-4">Result Images</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <img src={results.originalImage} alt="Original" className="rounded-lg w-full h-56 object-cover" />
                      <p className="text-sm text-center text-gray-500">Original Image</p>
                    </div>
                    <div className="space-y-2">
                      <img src={results.maskImage} alt="Green Mask" className="rounded-lg w-full h-56 object-cover" />
                      <p className="text-sm text-center text-gray-500">Green Mask</p>
                    </div>
                    <div className="space-y-2">
                      <img src={results.highlightedImage} alt="Highlighted" className="rounded-lg w-full h-56 object-cover" />
                      <p className="text-sm text-center text-gray-500">Infected Region Highlighted</p>
                    </div>
                  </div>
                  
                  <Button 
                    onClick={handleDownloadReport} 
                    className="w-full mt-8 bg-agro-accent hover:bg-agro-accent/90 text-gray-800"
                  >
                    <Download className="mr-2 h-4 w-4" /> Download Report (PDF)
                  </Button>
                  
                  <Button
                    onClick={() => {
                      setResults(null);
                      setFile(null);
                      setPreviewUrl(null);
                      setImageId('');
                    }}
                    variant="outline"
                    className="w-full mt-4"
                  >
                    Analyze Another Image
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default Services;
